#include <bits/stdc++.h>
#define ll long long
using namespace std;

int main() {
  ll n, m, k;
  ll arr[n], dp[n];
  if (n <= k) {
    cout << n << "\n";
  } else {
    for (int i=0; i<n; i++) {
      cin >> arr[i];
    }

  return 0;
}

