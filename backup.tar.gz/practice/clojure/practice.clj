(require '[clojure.string :as str])
(str/blank? " ")

