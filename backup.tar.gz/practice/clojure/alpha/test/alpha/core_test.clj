(ns alpha.core-test
  (:require [clojure.test :refer :all]
            [alpha.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
