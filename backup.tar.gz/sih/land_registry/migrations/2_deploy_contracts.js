var Land = artifacts.require("./Land.sol");

module.exports = function(deployer) {
  deployer.deploy(Land);
};
